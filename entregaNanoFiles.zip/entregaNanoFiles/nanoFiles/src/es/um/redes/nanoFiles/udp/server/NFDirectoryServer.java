package es.um.redes.nanoFiles.udp.server;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.stream.Collectors;

import es.um.redes.nanoFiles.application.NanoFiles;
import es.um.redes.nanoFiles.udp.message.DirMessage;
import es.um.redes.nanoFiles.udp.message.DirMessageOps;
import es.um.redes.nanoFiles.util.FileInfo;
import es.um.redes.nanoFiles.util.NickGenerator;

public class NFDirectoryServer {
	
	/**
	 * Número de puerto UDP en el que escucha el directorio
	 */
	public static final int DIRECTORY_PORT = 6868;
	private static final int FILES_TO_SENT = 9;
	private static final int ACK_TIMEOUT = 2000;
	private static final int MAX_ACK_ATTEMPTS = 5;
	
	/**
	 * Socket de comunicación UDP con el cliente UDP (DirectoryConnector)
	 */
	private DatagramSocket socket = null;
	/*
	 * TODO: Añadir aquí como atributos las estructuras de datos que sean necesarias
	 * para mantener en el directorio cualquier información necesaria para la
	 * funcionalidad del sistema nanoFilesP2P: ficheros alojados, servidores
	 * registrados, etc.
	 */
	/**
	 * Lista de ficheros alojados en el directorio.
	 */
	private FileInfo[] directoryFiles;
	/**
	 * Lista de servidores registrados (IP, puerto TCP).
	 */
	private LinkedHashMap<String, InetSocketAddress> registeredPeers;

	/**
	 * Probabilidad de descartar un mensaje recibido en el directorio (para simular
	 * enlace no confiable y testear el código de retransmisión)
	 */
	private double messageDiscardProbability;
	
	
	private DatagramPacket enviarRecibirPaquete( DirMessage m, InetSocketAddress addr) throws IOException{
		String responseString = m.toString();
		byte[] responseData=responseString.getBytes();
		DatagramPacket responsePacket=new DatagramPacket(responseData, responseData.length, addr);
		int previousTimeout = socket.getSoTimeout();
		try{
			socket.setSoTimeout(ACK_TIMEOUT);
			for( int i = 0; i < MAX_ACK_ATTEMPTS; i++) {
				socket.send(responsePacket);
				try {
					DatagramPacket ack_pkt=receiveDatagram();
					return ack_pkt;
				}catch(SocketTimeoutException e) {
					System.err.println("Timeout waiting for ack, retrying...");
				}
			}
			throw new SocketTimeoutException("Max retries reached waiting for ack");
		}finally {
			socket.setSoTimeout(previousTimeout);
		}
	}

	public NFDirectoryServer(double corruptionProbability, String directoryFilesPath) throws SocketException {
		/*
		 * Guardar la probabilidad de pérdida de datagramas (simular enlace no
		 * confiable)
		 */
		messageDiscardProbability = corruptionProbability;
		/*
		 * Cargar los ficheros del directorio compartido.
		 */
		File dir = new File(directoryFilesPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		directoryFiles = FileInfo.loadFilesFromFolder(directoryFilesPath);
		System.out.println("* Directory loaded " + directoryFiles.length + " files from " + directoryFilesPath);
		/*
		 * TODO: (Boletín SocketsUDP) Inicializar el atributo socket: Crear un socket
		 * UDP ligado al puerto especificado por el argumento directoryPort en la
		 * máquina local,
		 */
		/*
		 * TODO: (Boletín SocketsUDP) Inicializar atributos que mantienen el estado del
		 * servidor de directorio: peers registrados, etc.)
		 */
		registeredPeers=new LinkedHashMap<>();
		
		socket=new DatagramSocket(DIRECTORY_PORT);

		if (NanoFiles.testModeUDP) {
			if (socket == null) {
				System.err.println("[testMode] NFDirectoryServer: code not yet fully functional.\n"
						+ "Check that all TODOs in its constructor and 'run' methods have been correctly addressed!");
				System.exit(-1);
			}
		}
	}

	public DatagramPacket receiveDatagram() throws IOException {
		DatagramPacket datagramReceivedFromClient = null;
		boolean datagramReceived = false;
		while (!datagramReceived) {
			/*
			 * TODO: (Boletín SocketsUDP) Crear un búfer para recibir datagramas y un
			 * datagrama asociado al búfer (datagramReceivedFromClient)
			 */
			/*
			 * TODO: (Boletín SocketsUDP) Recibimos a través del socket un datagrama
			 */

			byte[] recvBuf = new byte[DirMessage.PACKET_MAX_SIZE];
			datagramReceivedFromClient=new DatagramPacket(recvBuf, recvBuf.length);
			
			//socket.setSoTimeout(2000); TODO esto que?
			
			socket.receive(datagramReceivedFromClient);

			if (datagramReceivedFromClient == null) {
				System.err.println("[testMode] NFDirectoryServer.receiveDatagram: code not yet fully functional.\n"
						+ "Check that all TODOs have been correctly addressed!");
				System.exit(-1);
			} else {
				// Vemos si el mensaje debe ser ignorado (simulación de un canal no confiable)
				double rand = Math.random();
				if (rand < messageDiscardProbability) {
					System.err.println(
							"Directory ignored datagram from " + datagramReceivedFromClient.getSocketAddress());
				} else {
					datagramReceived = true;
				}
			}

		}

		return datagramReceivedFromClient;
	}

	public void runTest() throws IOException {

		System.out.println("[testMode] Directory starting...");

		System.out.println("[testMode] Attempting to receive 'ping' message...");
		DatagramPacket rcvDatagram = receiveDatagram();
		sendResponseTestMode(rcvDatagram);

		System.out.println("[testMode] Attempting to receive 'ping&PROTOCOL_ID' message...");
		rcvDatagram = receiveDatagram();
		sendResponseTestMode(rcvDatagram);
	}

	private void sendResponseTestMode(DatagramPacket pkt) throws IOException {
		/*
		 * TODO: (Boletín SocketsUDP) Construir un String partir de los datos recibidos
		 * en el datagrama pkt. A continuación, imprimir por pantalla dicha cadena a
		 * modo de depuración.
		 */

		String receivedMessage=new String(pkt.getData(), 0, pkt.getLength());
		System.out.println(receivedMessage);
		
		/*
		 * TODO: (Boletín SocketsUDP) Después, usar la cadena para comprobar que su
		 * valor es "ping"; en ese caso, enviar como respuesta un datagrama con la
		 * cadena "pingok". Si el mensaje recibido no es "ping", se informa del error y
		 * se envía "invalid" como respuesta.
		 */

		String messageToClient;
		if(receivedMessage.equals("ping")) {
		
			messageToClient = new String("pingok");	
		}
		else if(receivedMessage.startsWith("ping&")){
			
			String protocolID=receivedMessage.split("&")[1];
			String directoryProtocolID=NanoFiles.PROTOCOL_ID;
			
			if(protocolID.contentEquals(directoryProtocolID)) {
				
				messageToClient = new String("welcome");
			}
			else {
				
				messageToClient = new String("denied");
				}
		}
		else { 
			System.err.println("Mensaje inválido");
			messageToClient = new String("invalid");
		}
		byte[] dataToClient = messageToClient.getBytes();
		InetSocketAddress clientAddr = (InetSocketAddress) pkt.getSocketAddress();
		System.out.println(
				"Sending datagram with message \"" + messageToClient + "\"");
		System.out.println("Destination is client at addr: " + clientAddr);
		DatagramPacket packetToClient = new DatagramPacket(dataToClient, dataToClient.length, clientAddr);
		socket.send(packetToClient);
	
		
		/*
		 * TODO: (Boletín Estructura-NanoFiles) Ampliar el código para que, en el caso
		 * de que la cadena recibida no sea exactamente "ping", comprobar si comienza
		 * por "ping&" (es del tipo "ping&PROTOCOL_ID", donde PROTOCOL_ID será el
		 * identificador del protocolo diseñado por el grupo de prácticas (ver
		 * NanoFiles.PROTOCOL_ID). Se debe extraer el "protocol_id" de la cadena
		 * recibida y comprobar que su valor coincide con el de NanoFiles.PROTOCOL_ID,
		 * en cuyo caso se responderá con "welcome" (en otro caso, "denied").
		 */

		String messageFromClient = new String(pkt.getData(), 0, pkt.getLength());
		System.out.println("Data received: " + messageFromClient);



	}

	public void run() throws IOException {

		System.out.println("Directory starting...");

		while (true) { // Bucle principal del servidor de directorio
			DatagramPacket rcvDatagram = receiveDatagram();

			sendResponse(rcvDatagram);

		}
	}

	private void sendResponse(DatagramPacket pkt) throws IOException {
		/*
		 * TODO: (Boletín MensajesASCII) Construir String partir de los datos recibidos
		 * en el datagrama pkt. A continuación, imprimir por pantalla dicha cadena a
		 * modo de depuración. Después, usar la cadena para construir un objeto
		 * DirMessage que contenga en sus atributos los valores del mensaje. A partir de
		 * este objeto, se podrá obtener los valores de los campos del mensaje mediante
		 * métodos "getter" para procesar el mensaje y consultar/modificar el estado del
		 * servidor.
		 */

		String requestString=new String(pkt.getData(), 0, pkt.getLength());
		System.out.println(requestString);
		DirMessage request=DirMessage.fromString(requestString);
		
		

		/*
		 * TODO: Una vez construido un objeto DirMessage con el contenido del datagrama
		 * recibido, obtener el tipo de operación solicitada por el mensaje y actuar en
		 * consecuencia, enviando uno u otro tipo de mensaje en respuesta.
		 */
		String operation = request.getOperation(); // TODO: Cambiar!

		/*
		 * TODO: (Boletín MensajesASCII) Construir un objeto DirMessage (msgToSend) con
		 * la respuesta a enviar al cliente, en función del tipo de mensaje recibido,
		 * leyendo/modificando según sea necesario el "estado" guardado en el servidor
		 * de directorio (atributos files, etc.). Los atributos del objeto DirMessage
		 * contendrán los valores adecuados para los diferentes campos del mensaje a
		 * enviar como respuesta (operation, etc.)
		 */
		
		DirMessage response=new DirMessage(DirMessageOps.OPERATION_INVALID);

		switch (operation) {
		case DirMessageOps.OPERATION_PING: {
			
			if(request.getProtocolId().equals(NanoFiles.PROTOCOL_ID)) {
				System.out.println("Ping succesful");
				response=new DirMessage(DirMessageOps.OPERATION_PING_OK);
			}
			else {
				System.out.println("Ping failed");
				response=new DirMessage(DirMessageOps.OPERATION_PING_ERROR);
			}

			/*
			 * TODO: (Boletín MensajesASCII) Comprobamos si el protocolId del mensaje del
			 * cliente coincide con el nuestro.
			 */
			/*
			 * TODO: (Boletín MensajesASCII) Construimos un mensaje de respuesta que indique
			 * el éxito/fracaso del ping (compatible, incompatible), y lo devolvemos como
			 * resultado del método.
			 */
			/*
			 * TODO: (Boletín MensajesASCII) Imprimimos por pantalla el resultado de
			 * procesar la petición recibida (éxito o fracaso) con los datos relevantes, a
			 * modo de depuración en el servidor
			 */



			break;
		}
		
		case DirMessageOps.OPERATION_DIRFILES_REQ: {
				int totalFiles = directoryFiles.length;
				int chunkSize = FILES_TO_SENT;
				int fin;
				boolean received;
				DatagramPacket ack_pkt;
				
				for(int i = 0; i < totalFiles; i += chunkSize) {
					received = false;
					while( !received ) {
						try {

							response = new DirMessage(DirMessageOps.OPERATION_DIRFILES_REP);
							response.setBlockNumber(i/FILES_TO_SENT);
							fin = Math.min(i + chunkSize, totalFiles);
							for( int j = i; j < fin; j ++) {
								response.addFile(directoryFiles[j]);
							}
							ack_pkt = enviarRecibirPaquete(response, (InetSocketAddress)pkt.getSocketAddress());
							request = DirMessage.fromString(new String( ack_pkt.getData(), 0, ack_pkt.getLength()));
							
							if(request.getOperation().equals(DirMessageOps.OPERATION_DIRFILES_ACK) && request.getAckNumber() == (i/FILES_TO_SENT)) {
								received = true;
							}	
						}catch(IOException e) {
							response=new DirMessage(DirMessageOps.OPERATION_DIRFILES_ERROR);
							response.setErrorInfo("");
							System.err.println(e.getMessage());	
							return;
						}
					}
					System.out.println("Block "+ (i/FILES_TO_SENT) + " successfully sent");
		
				}

				
				response=new DirMessage(DirMessageOps.OPERATION_DIRFILES_OK);
				System.out.println("Files sent successfully");
				
				break;
		}
		case DirMessageOps.OPERATION_SERVE: {
			
			String requestNickname=request.getServerNickname();
			InetSocketAddress requestAddress=new InetSocketAddress(pkt.getAddress(), request.getServerPort()); //obtenemos la dirección IP de la que viene el paquete
			
			if(!registeredPeers.containsKey(requestNickname)) {
				registeredPeers.put(requestNickname, requestAddress);
				response=new DirMessage(DirMessageOps.OPERATION_SERVE_OK);
				
				response.setServerNickname(requestNickname); 
			}
			else if(!registeredPeers.get(requestNickname).equals(requestAddress)){
				while (registeredPeers.containsKey(requestNickname)) {
					requestNickname=NickGenerator.randomNickname();
				}
				
				registeredPeers.put(requestNickname, requestAddress);
				response=new DirMessage(DirMessageOps.OPERATION_SERVE_OK);
				
				response.setServerNickname(requestNickname); //pasamos el nickname final con el que se ha registrado el server
			}
			else {
				response=new DirMessage(DirMessageOps.OPERATION_SERVE_OK);
			}
			
			break;
		}
		case DirMessageOps.OPERATION_PEERS: {
				response=new DirMessage(DirMessageOps.OPERATION_PEERS_OK);
				for(String peer : registeredPeers.keySet()) {
					response.addPeerList(peer, registeredPeers.get(peer));
				}

			
			break;
		}
		case DirMessageOps.OPERATION_DIRDL_REQ: {
			String subHash=request.getSubHash();
			FileInfo[] matchingFiles=Arrays.stream(directoryFiles).
					filter(f -> f.fileHash.contains(subHash)).
					collect(Collectors.toList()).
					toArray(FileInfo[]::new);
			if(matchingFiles.length==1) {
				
				File file=new File(matchingFiles[0].filePath);
				long fileSize=matchingFiles[0].fileSize;
				String fileHash=matchingFiles[0].fileHash;
				String filaName=matchingFiles[0].fileName;
				
				long chunkNumber=Math.ceilDiv(fileSize, DirMessage.CHUNK_MAX_SIZE);
				
				long offset;
				int cantidad;
				boolean received;
				DatagramPacket ack_pkt;
				
				RandomAccessFile f=new RandomAccessFile(file, "r");
				
				for(long i=0; i<chunkNumber; i++) {
					
					offset=DirMessage.CHUNK_MAX_SIZE * i;
					cantidad=(int) Math.min(DirMessage.CHUNK_MAX_SIZE, fileSize - offset);
					
					byte[] dataToRead=new byte[cantidad];
						
					f.seek(offset);
					f.readFully(dataToRead);
					
					received = false;
					while( !received ) {
						
						try {
							response=new DirMessage(DirMessageOps.OPERATION_DIRDL_REPLY);
							response.setBlockNumber(i);
							response.setData(dataToRead);
							
							ack_pkt=enviarRecibirPaquete(response, (InetSocketAddress)pkt.getSocketAddress());
							request=DirMessage.fromString(new String(ack_pkt.getData(), 0, ack_pkt.getLength()));
							
							if(request.getOperation().equals(DirMessageOps.OPERATION_DIRDL_ACK) && request.getAckNumber() == i) {
								received = true;
							}
						}
						catch(IOException e) { //esto tambien tiene en cuenta los timeout
							response=new DirMessage(DirMessageOps.OPERATION_DIRDL_ERROR);
							response.setErrorInfo("");
							System.err.println(e.getMessage());
							f.close();
							return;
						}
					}
					
					System.out.println("Block "+ i + " successfully sent"); //TODO debug, lo quitamos al final
						
				}
					
				f.close();
				
				response=new DirMessage(DirMessageOps.OPERATION_DIRDL_OK);
				response.setFileSize(fileSize);
				response.setFileName(filaName);
				response.setSubHash(fileHash);
				System.out.println("File sent successfully");
				
			}
			else if(matchingFiles.length!=0){
				response=new DirMessage(DirMessageOps.OPERATION_DIRDL_ERROR);
				response.setErrorInfo("Serveral files contain the same subhash");
			}
			else {
				response=new DirMessage(DirMessageOps.OPERATION_DIRDL_ERROR);
				response.setErrorInfo("No file matches the subhash");
			}
			
			break;
			
		}
		case DirMessageOps.OPERATION_QUIT: {
			
			String nickname=request.getNickname();
			if(registeredPeers.remove(nickname) !=null) {
				System.out.println("Quit successful");
				response=new DirMessage(DirMessageOps.OPERATION_QUIT_OK);
			}
			else {
				System.out.println("Quit failed");
				response=new DirMessage(DirMessageOps.OPERATION_QUIT_ERROR);
			}
			
			break;
		}
		default:
			System.err.println("Unexpected message operation: \"" + operation + "\"");
		}

		/*
		 * TODO: (Boletín MensajesASCII) Convertir a String el objeto DirMessage
		 * (msgToSend) con el mensaje de respuesta a enviar, extraer los bytes en que se
		 * codifica el string y finalmente enviarlos en un datagrama
		 */
		if(!operation.equals(DirMessageOps.OPERATION_DIRDL_REPLY)
				&& !operation.equals(DirMessageOps.OPERATION_DIRFILES_REP)) {
			String responseString=response.toString();
			byte[] responseData=responseString.getBytes();
			InetSocketAddress clientAddr = (InetSocketAddress) pkt.getSocketAddress();
			DatagramPacket responsePacket=new DatagramPacket(responseData, responseData.length, clientAddr);
			socket.send(responsePacket);
		}	

	}




}
